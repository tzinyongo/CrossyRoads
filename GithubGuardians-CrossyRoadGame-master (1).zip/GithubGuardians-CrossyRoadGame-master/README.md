# GithubGuardians-CrossyRoadGame

# make sure to have a version of android studios downloaded
# go the the main branch (not master) and pull the files from there - those are the files that run the game 
# make sure all the files are downloaded then go to GameplayActivity.java and run the app 
